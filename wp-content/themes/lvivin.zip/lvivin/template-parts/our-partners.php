<div class="container fifth-content">
	<div class="sign-line">НАШІ ПАРТНЕРИ</div>
	<div class="line-main">
		<div class="block-line-black "></div>
	</div>
	<div class="center partners-slider">
		<div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:350px;overflow:hidden;visibility:hidden;">
			<!-- Loading Screen -->
			<div data-u="loading" style="position:absolute;top:0px;left:0px;background-color:rgba(0,0,0,0.7);">
				<div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
				<div style="position:absolute;display:block;background:url('<?php echo get_template_directory_uri(); ?>/img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
			</div>
			<div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:100%;height:350px;overflow:hidden;">
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners.png" /> </a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners1.gif" /></a>
				</div>
				<div>
					<a href="URL">  <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners2.png" /></a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners3.png" /></a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners4.jpg" /></a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners.png" /></a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners1.gif" /></a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners2.png" /></a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners3.png" /></a>
				</div>
				<div>
					<a href="URL"> <img class="partners-img" data-u="image" alt="partners" src="<?php echo get_template_directory_uri(); ?>/img/partners/partners4.jpg" /></a>
				</div>
			</div>
		</div>
	</div>
</div>