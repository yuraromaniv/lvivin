<?php 
    //header
    get_header();

    //content-home
    get_template_part('/template-parts/content', 'home');

    //footer
    get_footer();
?>
