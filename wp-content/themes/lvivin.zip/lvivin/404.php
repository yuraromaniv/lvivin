<?php get_header() ?>

<div style="margin-top:250px; margin-bottom:250px; height: 20vh">
    <h1> Error 404! </h1>
</div>
<?php get_footer(); ?>
